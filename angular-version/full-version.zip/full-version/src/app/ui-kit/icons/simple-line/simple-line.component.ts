import { Component } from '@angular/core';

@Component({
  selector: 'app-simple-line',
  templateUrl: './simple-line.component.html',
  styleUrls: ['./simple-line.component.scss']
})
export class SimpleLineComponent {
}
