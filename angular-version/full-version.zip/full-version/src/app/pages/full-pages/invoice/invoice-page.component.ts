import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-invoice-page',
    templateUrl: './invoice-page.component.html',
    styleUrls: ['./invoice-page.component.scss']
})

export class InvoicePageComponent {

}